#pragma once

static constexpr int optionButtonHeight = 70;
static constexpr int optionButtonWidth = 300;
static constexpr int optionButtonPad = 20;
static constexpr int optionTriangleHeight = 25;